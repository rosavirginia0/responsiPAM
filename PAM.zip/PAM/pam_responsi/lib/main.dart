import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'pages/login_page.dart';
import 'pages/register_page.dart';
import 'pages/list_page.dart';
import 'pages/favorite_page.dart';
import 'pages/detail_page.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Restaurant App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: SplashScreen(),
      routes: {
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/list': (context) => ListPage(),
        '/favorite': (context) => FavoritePage(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/detail') {
          final restaurantId = settings.arguments as String;
          return MaterialPageRoute(
            builder: (context) => DetailPage(restaurantId: restaurantId),
          );
        }
        return null;
      },
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  Future<bool> _checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('loggedInUser');
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _checkLoginStatus(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
        if (snapshot.data == true) {
          // Pengguna sudah login, arahkan ke halaman daftar restoran
          Future.microtask(() {
            Navigator.pushReplacementNamed(context, '/list');
          });
        } else {
          // Pengguna belum login, arahkan ke halaman login
          Future.microtask(() {
            Navigator.pushReplacementNamed(context, '/login');
          });
        }
        return Container(); // Placeholder sementara
      },
    );
  }
}