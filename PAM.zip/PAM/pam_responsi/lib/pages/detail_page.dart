import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:pam_responsi/pages/restaurant_model.dart';
import 'package:pam_responsi/pages/api_service.dart';

class DetailPage extends StatefulWidget {
  final String restaurantId;

  DetailPage({required this.restaurantId});

  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late Future<Restaurant> restaurant;
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    restaurant = ApiService.fetchRestaurantDetail(widget.restaurantId).then((data) {
      _checkIfFavorite(data.id);
      return data;
    });
  }

  Future<void> _checkIfFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];
    setState(() {
      isFavorite = favorites.any((item) {
        final favorite = jsonDecode(item);
        return favorite['id'] == id;
      });
    });
  }

  Future<void> _toggleFavorite(Restaurant restaurant) async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];
    final isAlreadyFavorite = favorites.any((item) {
      final favorite = jsonDecode(item);
      return favorite['id'] == restaurant.id;
    });

    if (isAlreadyFavorite) {
      final updatedFavorites = favorites.where((item) {
        final favorite = jsonDecode(item);
        return favorite['id'] != restaurant.id;
      }).toList();
      await prefs.setStringList('favorites', updatedFavorites);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${restaurant.name} removed from favorites!'), backgroundColor: Colors.red),
      );
    } else {
      favorites.add(jsonEncode(restaurant.toJson()));
      await prefs.setStringList('favorites', favorites);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${restaurant.name} added to favorites!'), backgroundColor: Colors.green),
      );
    }

    setState(() {
      isFavorite = !isFavorite;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[800],
        title: Text('Detail Restaurant'),
      ),
      body: FutureBuilder<Restaurant>(
        future: restaurant,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final data = snapshot.data!;
          return ListView(
            padding: EdgeInsets.all(16.0),
            children: [
              Image.network(
                "https://restaurant-api.dicoding.dev/images/large/${data.id}",
                fit: BoxFit.cover,
              ),
              SizedBox(height: 16.0),
              Text(
                data.name,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              Text('${data.city}, ${data.address}'),
              Text('Rating: ${data.rating}'),
              SizedBox(height: 8.0),
              Text(data.description),
              Align(
                alignment: Alignment.centerRight,
                child: IconButton(
                  icon: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? Colors.red : Colors.grey,
                    size: 30,
                  ),
                  onPressed: () async => await _toggleFavorite(data),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}