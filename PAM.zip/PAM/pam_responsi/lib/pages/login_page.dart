import 'package:flutter/material.dart';
import 'package:pam_responsi/pages/session_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatelessWidget {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  LoginPage({super.key});

  Future<void> login(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final users = prefs.getStringList('users') ?? [];
    final inputUsername = usernameController.text;
    final inputPassword = passwordController.text;

    if (users.any((user) {
      final details = user.split(':');
      return details[0] == inputUsername && details[1] == inputPassword;
    })) {
      // Simpan sesi login menggunakan SessionManager
      await SessionManager.setLoggedIn(inputUsername);
      Navigator.pushReplacementNamed(context, '/list');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid username or password')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: usernameController, decoration: const InputDecoration(labelText: 'Username')),
            TextField(controller: passwordController, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            ElevatedButton(onPressed: () => login(context), child: const Text('Login')),
            TextButton(onPressed: () => Navigator.pushNamed(context, '/register'), child: const Text('Register')),
          ],
        ),
      ),
    );
  }
}