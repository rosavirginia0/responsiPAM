import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:pam_responsi/pages/restaurant_model.dart';

class ApiService {
  static const String baseUrl = 'https://restaurant-api.dicoding.dev';

  static Future<List<Map<String, dynamic>>> fetchRestaurants() async {
    final response = await http.get(Uri.parse('$baseUrl/list'));
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      return List<Map<String, dynamic>>.from(data['restaurants']);
    } else {
      throw Exception('Failed to load restaurants');
    }
  }

  static Future<Restaurant> fetchRestaurantDetail(String id) async {
    final response = await http.get(Uri.parse('$baseUrl/detail/$id'));
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      return Restaurant.fromJson(data['restaurant']);
    } else {
      throw Exception('Failed to load restaurant detail');
    }
  }
}