import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class FavoritePage extends StatefulWidget {
  @override
  _FavoritePageState createState() => _FavoritePageState();
}

class _FavoritePageState extends State<FavoritePage> {
  List<Map<String, dynamic>> favoriteRestaurants = [];

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
  final prefs = await SharedPreferences.getInstance();
  final favorites = prefs.getStringList('favorites') ?? [];
  setState(() {
    favoriteRestaurants = favorites
        .map((item) => Map<String, dynamic>.from(jsonDecode(item)))
        .toList();
  });
}

  Future<void> _removeFromFavorites(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];
    final updatedFavorites = favorites.where((item) {
      final restaurant = jsonDecode(item);
      return restaurant['id'] != id;
    }).toList();
    await prefs.setStringList('favorites', updatedFavorites);
    _loadFavorites();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Favorite Restaurants'),
      ),
      body: favoriteRestaurants.isEmpty
          ? Center(child: Text('No favorites yet!'))
          : ListView.builder(
              itemCount: favoriteRestaurants.length,
              itemBuilder: (context, index) {
                final restaurant = favoriteRestaurants[index];
                return ListTile(
                  leading: Image.network(
                    "https://restaurant-api.dicoding.dev/images/small/${restaurant['pictureId']}",
                    width: 50,
                    fit: BoxFit.cover,
                  ),
                  title: Text(restaurant['name']),
                  subtitle: Text(restaurant['city']),
                  trailing: IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _removeFromFavorites(restaurant['id']),
                  ),
                );
              },
            ),
    );
  }
}