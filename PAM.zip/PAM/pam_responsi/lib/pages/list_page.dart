import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pam_responsi/pages/api_service.dart';

class ListPage extends StatefulWidget {
  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  String username = '';
  List<String> favoriteIds = []; // Menyimpan daftar ID restoran favorit

  @override
  void initState() {
    super.initState();
    _loadUsername();
    _loadFavorites();
  }

  Future<void> _loadUsername() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      username = prefs.getString('loggedInUser') ?? 'Guest';
    });
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      favoriteIds = prefs.getStringList('favorites') ?? [];
    });
  }

  Future<void> _toggleFavorite(String restaurantId, String restaurantName) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> updatedFavorites = [...favoriteIds];

    if (favoriteIds.contains(restaurantId)) {
      // Jika sudah di favorit, hapus
      updatedFavorites.remove(restaurantId);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$restaurantName berhasil dihapus dari favorit!'),
          backgroundColor: Colors.red,
        ),
      );
    } else {
      // Jika belum di favorit, tambahkan
      updatedFavorites.add(restaurantId);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$restaurantName berhasil ditambahkan ke favorit!'),
          backgroundColor: Colors.green,
        ),
      );
    }

    await prefs.setStringList('favorites', updatedFavorites);

    setState(() {
      favoriteIds = updatedFavorites;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[800],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Tombol kembali
          },
        ),
        title: Text("Hi, $username"),
        centerTitle: true,
        actions: [
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert),
            onSelected: (value) {
              if (value == 'favorites') {
                Navigator.pushNamed(context, '/favorite');
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'favorites',
                child: Text('Favorites'),
              ),
            ],
          ),
        ],
      ),
      body: FutureBuilder(
        future: ApiService.fetchRestaurants(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final restaurants = snapshot.data as List;
          return ListView.builder(
            itemCount: restaurants.length,
            itemBuilder: (context, index) {
              final restaurant = restaurants[index];
              final isFavorite = favoriteIds.contains(restaurant['id']); // Cek apakah restoran ini favorit
              return ListTile(
                leading: Image.network(
                  "https://restaurant-api.dicoding.dev/images/small/${restaurant['pictureId']}",
                  width: 50,
                  fit: BoxFit.cover,
                ),
                title: Text(restaurant['name']),
                subtitle: Text(restaurant['city']),
                trailing: IconButton(
                  icon: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? Colors.red : Colors.grey,
                  ),
                  onPressed: () => _toggleFavorite(restaurant['id'], restaurant['name']),
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/detail', arguments: restaurant['id']);
                },
              );
            },
          );
        },
      ),
    );
  }
}