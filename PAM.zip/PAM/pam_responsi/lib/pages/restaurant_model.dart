class Restaurant {
  final String id;
  final String name;
  final String city;
  final String address;
  final double rating;
  final String description;

  Restaurant({
    required this.id,
    required this.name,
    required this.city,
    required this.address,
    required this.rating,
    required this.description,
  });

  factory Restaurant.fromJson(Map<String, dynamic> json) {
    return Restaurant(
      id: json['id'],
      name: json['name'],
      city: json['city'],
      address: json['address'] ?? '',
      rating: (json['rating'] is int) ? (json['rating'] as int).toDouble() : json['rating'],
      description: json['description'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'city': city,
      'address': address,
      'rating': rating,
      'description': description,
    };
  }
}