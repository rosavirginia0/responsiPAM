import 'package:shared_preferences/shared_preferences.dart';

class SessionManager {
  static const String _loggedInKey = 'loggedInUser';

  // Simpan nama pengguna saat login
  static Future<void> setLoggedIn(String username) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_loggedInKey, username);
  }

  // Ambil nama pengguna yang login
  static Future<String?> getLoggedInUser() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_loggedInKey);
  }

  // Hapus sesi login (logout)
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_loggedInKey);
  }
}