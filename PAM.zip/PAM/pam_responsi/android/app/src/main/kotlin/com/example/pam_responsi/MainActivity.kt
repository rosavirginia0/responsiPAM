package com.example.pam_responsi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
