import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'list_page.dart';

class HomePage extends StatelessWidget {
  Future<String> _getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('username') ?? 'Guest';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber[800], // Kuning mustard
        title: FutureBuilder<String>(
          future: _getUsername(),
          builder: (context, snapshot) {
            return Text(snapshot.data ?? 'Home');
          },
        ),
      ),
      body: Center(  // Membuat seluruh body berada di tengah
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,  // Rata tengah secara vertikal
            children: [
              _menuItem(
                context,
                'Restoran',
                'assets/images/news.png',  // Gambar untuk menu News
                'Get the latest updates on spaceflight news.',
                'Restoran',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _menuItem(
      BuildContext context,
      String title,
      String imagePath,
      String description,
      String category,
      ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: Image.asset(imagePath, width: 50, height: 50, fit: BoxFit.cover),
        title: Text(title),
        subtitle: Text(description),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ListPage(category: category)),
          );
        },
      ),
    );
  }
}