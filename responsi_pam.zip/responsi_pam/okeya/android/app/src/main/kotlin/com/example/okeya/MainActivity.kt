package com.example.okeya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
